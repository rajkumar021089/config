# Validation results

Run on Java 17; compiled with --release 11.

Core and simulated API fixtures only; NO real webMethods server test performed.

```text
PASS startup loads common
PASS environment file merges
PASS UTF-8 survives
PASS save does not update cache
PASS stale edit rejected
PASS reset activates saved value
PASS restart reloads saved value
PASS package traversal rejected
PASS file traversal rejected
PASS unrelated config file rejected
PASS symlink rejected
PASS secret encrypted
PASS fresh nonce each encryption
PASS secret decrypts on retrieval
PASS ordinary lookup cannot return secret
PASS encrypted value bound to property key
PASS invalid file rejects whole reset
PASS failed reset preserves previous snapshot
PASS environment override wins
PASS missing key default
TOTAL 20 checks passed
PASS admin status allowed
PASS mutation without token denied
PASS tampered token denied
PASS anonymous denied
PASS unauthorized runtime read denied
config audit user=Administrator action=save package=config file=wxconfig.cnf
PASS IS save leaves old cache
config audit user=Administrator action=reset package=- file=-
PASS IS reset activates saved value
config audit user=Administrator action=saveSecret package=config file=wxconfig.cnf
PASS secret removed from output pipeline
PASS IS secret save encrypts file
config audit user=Administrator action=reset package=- file=-
PASS IS secret lookup decrypts
TOTAL 10 simulated-boundary checks passed
```

Additional checks: JavaScript syntax check passed; namespace XML parsed; JAR contains six application classes and no com.wm fixtures.

Browser UI test is included but was NOT executed successfully: no browser executable was installed, and browser download was unavailable. UI rendering and real IS HTTP behavior remain unverified.
