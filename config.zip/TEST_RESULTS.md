# Full package validation

50 local checks pass using simulated IS API fixtures. The executed class was reconstructed from delivered java.frag bodies and node.idf Shared Source/imports.

```text
PASS startup loads config.cnf
PASS environment override wins
PASS UTF-8 preserved
PASS configured global fallback
PASS ignoreGlobalValues suppresses fallback
PASS legacy configFile basename maps to new file
PASS Save leaves active cache unchanged
PASS stale save rejected
PASS reset activates saved value
PASS restart loads saved files
PASS package traversal rejected
PASS file traversal rejected
PASS unrelated file access rejected
PASS symbolic link rejected
PASS config file keeps encrypted handle syntax
PASS secret file contains no plaintext
PASS false returns handle reference
PASS true returns plaintext
PASS plaintext not cached by default
PASS secret store rejects plaintext
PASS bad config rejects reset
PASS failed reset retains old snapshot
PASS migration defaults to inspectable dry run
PASS dry run never decrypts old secrets
PASS dry run writes no targets
PASS other stages explicitly reported
PASS apply requires matching plan
PASS legacy resolution failure aborts migration
PASS failed resolution writes no targets
PASS migration applies
PASS migrated secret resolves without original service
PASS migrated environment auto-loaded
PASS legacy file untouched
PASS migration report contains no secret values
PASS repeat apply refuses overwrite
PASS repeat apply preserves target
PASS wrapper input/output contract
PASS service plaintext flag
PASS missing suppression returns null
PASS missing default throws
PASS excluded interpolation flag rejected
PASS reset without token denied
PASS tampered token denied
PASS anonymous runtime denied
PASS anonymous admin denied
PASS bulk response cannot mutate internal snapshot
PASS bulk returns snapshot version
PASS concurrent snapshot readers remain consistent during reset
PASS explicit decrypted-cache option works
PASS decrypted-cache lookup returns value
TOTAL 50 checks passed
```

Additional validation: Java compilation of visible implementation and all three command-line tools; JavaScript syntax; all namespace XML parses; nine input fields and propertyValue contract; all DSP pages have unique control IDs; no JARs/classes in deployed source package.

Not performed: actual IS 10.15/12.1 deployment, native Designer UI display, WmRoot menu registration, HTTP/DSP browser rendering, original WxConfig integration, or throughput certification. The JavaScript test dependency download was unavailable; UI behavior remains unverified. Concurrent snapshot consistency tests are functional tests, not an 8,000/s production benchmark.
