# Source-only revision validation

The class was reconstructed from the delivered java.frag bodies and the node.idf Shared Source/imports, then compiled with Java 17 (--release 11) against simulated IS API fixtures.

```text
PASS startup loads common
PASS environment file merges
PASS UTF-8 survives
PASS save does not update cache
PASS stale edit rejected
PASS reset activates saved value
PASS restart reloads saved value
PASS package traversal rejected
PASS file traversal rejected
PASS unrelated config file rejected
PASS symlink rejected
PASS secret encrypted
PASS fresh nonce each encryption
PASS secret decrypts on retrieval
PASS ordinary lookup cannot return secret
PASS encrypted value bound to property key
PASS invalid file rejects whole reset
PASS failed reset preserves previous snapshot
PASS environment override wins
PASS missing key default
TOTAL 20 checks passed
PASS admin status allowed
PASS mutation without token denied
PASS tampered token denied
PASS anonymous denied
PASS unauthorized runtime read denied
config audit user=Administrator action=save package=config file=wxconfig.cnf
PASS IS save leaves old cache
config audit user=Administrator action=reset package=- file=-
PASS IS reset activates saved value
config audit user=Administrator action=saveSecret package=config file=wxconfig.cnf
PASS secret removed from output pipeline
PASS IS secret save encrypts file
config audit user=Administrator action=reset package=- file=-
PASS IS secret lookup decrypts
TOTAL 10 simulated-boundary checks passed
```

All 30 checks passed. The two source-only Java tools compiled. All namespace XML parsed; all seven Java fragments contain actual method bodies; no external helper calls or custom JARs remain.

Actual IS service loading, Designer source display, ACL integration, Solutions menu and browser UI remain unverified without an IS server. Browser test is included but was not executed successfully in this environment.
