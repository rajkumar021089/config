# config — Integration Server configuration manager 1.0.0

Independent implementation requested by Raj. This is NOT the original WxConfig,
not an IBM product, and not a drop-in replacement for existing WxConfig APIs,
file syntax extensions or encrypted values.

## What is delivered

- Integration Server package named exactly `config`.
- Solutions menu callback, registration on startup and removal on shutdown.
- Browser UI at `/config/index.html` with package/file discovery and editor.
- Add/change/delete key=value lines; create wxconfig configuration files.
- Save persists file only. The active JVM cache remains unchanged.
- Reset Server Cache reads all common and active environment files and atomically
  publishes a new immutable snapshot. Failure leaves the old snapshot active.
- Startup/restart loads saved configuration; each IS JVM has its own cache.
- Runtime getValue and getSecret services.
- AES-256-GCM encrypted properties; ciphertext stays in the cache; decrypt on
  getSecret. Plaintext exists in the caller pipeline when consumed.
- Administrator checks in Java, CSRF tokens for mutations, optimistic file version
  checks, atomic saves, size limits and path/symlink restrictions.
- Full Java source, prebuilt Java 11 bytecode JAR, namespace service definitions,
  core tests and simulated IS-boundary tests. No third-party dependencies.

## Validation status — read before installation

20 core behavior tests and 10 simulated IS-boundary tests pass locally on Java 17.
JavaScript syntax and namespace XML checks passed. Browser rendering was not
verified because a browser binary was unavailable; the UI test is included.
Compilation used minimal local IS API signatures, NOT licensed webMethods JARs.
The test fixtures are under tests/fixtures and are never included in the package JAR.
No real IS 10.15/12.1 instance was available: service binding, ACL integration,
Solutions menu registration, HTTP serialization and the UI require the smoke test
below. A successful simulated test does not establish IS compatibility.

Targets IS 10.15 / 12.1 with Java 11+; actual deployment is unverified. If an API
signature/linkage error appears, rebuild against the target IS libraries with the
included rebuild.py. The menu uses internal WmRoot services and may need adjustment
for your server release. Direct UI URL remains available if registration fails.

## Installation — development IS first

1. Unzip this delivery outside the IS packages folder. Check that no package named
   `config` already exists; do not overwrite an existing package or namespace.
2. Copy ONLY the `config` folder to:
   `<IS_HOME>/instances/<instance>/packages/config`
   For an installation without instances, use its actual `packages` directory.
   This ZIP is a directory-copy delivery, not an IS replication/inbound archive.
3. Edit `packages/config/config/manager.properties`:
   `environment=dev` (or uat/prod). Environment names must be alphanumeric,
   underscore, period or hyphen, but environment filenames use alphanumeric and
   underscore only; use simple names such as dev/uat/prod.
4. Load/reload the package from IS Administrator > Packages > Management.
   The manifest registers `config.lifecycle:startup` as startup service.
   Confirm package loading and startup success in the server log.
5. In Designer set List/Read/Write/Execute ACLs for `config.admin` and
   `config.lifecycle` to **Administrators**, inherited by child services.
   Set the same ACLs for `config.pub` initially. Disable service audit document/
   pipeline logging, especially for getSecret and dispatch. The Java boundary
   ALSO checks the Administrators ACL; it fails closed if validation is unavailable.
   These one-time ACL settings are required to establish the HTTP authentication
   challenge and restrict metadata visibility. They are not auto-written into
   server-wide ACL maps by this delivery.
6. Sign in as an IS administrator; refresh the Administrator page. Find
   Solutions > Configuration. If absent run `config.lifecycle:startup` once
   from Designer; inspect its server log warning and use the direct URL:
   `https://<host>:<admin-port>/config/index.html`.
7. Select package `config`, open wxconfig.cnf and perform the smoke test.
   Use HTTPS; secret input must not travel over unencrypted HTTP.

If root discovery fails, set a JVM property pointing to the actual packages root:
`-Dconfig.packagesRoot=C:/SoftwareAG/IntegrationServer/instances/default/packages`
or the Linux equivalent. The default discovers the config package using
`Server.getResources().getPackageConfigDir("config")`.

## File selection and format

All installed on-disk package directories with manifest.v3 appear, including
packages that may be disabled in IS. Only regular files named `wxconfig.cnf` or
`wxconfig-<environment>.cnf` inside each package's config directory are managed.
Packages without a config directory are listed but cannot create files until
an administrator creates that directory on disk.

Files use UTF-8 Java properties syntax (key=value, # comments, backslash escapes,
continuation lines). Duplicate keys follow Java Properties behavior: last wins.
When writing Windows paths, use forward slashes or double backslashes.
Unknown .cnf formats, XML, Apache Commons includes, interpolation, special list
syntax and original WxConfig encrypted values are not interpreted. Review existing
files before loading them; do not deploy this package over original WxConfig files
without validating their syntax and behavior.

Load precedence for each package:
1. config/wxconfig.cnf
2. config/wxconfig-<active-environment>.cnf (overrides common keys)

Other environment files remain viewable/editable without becoming active. The
active environment is read from config/config/manager.properties on startup/reset.
Edit this setting on disk then Reset Server Cache. Save in the browser never calls
reset. Viewing files also never changes the runtime snapshot.

The editor preserves text on ordinary Save. Encrypt-and-save uses Properties.store,
which rewrites ordering, formatting and comments. Save editor changes first.
The file-version hash prevents overwriting another editor's newer file.
Atomic replacement is required; unsupported filesystems report an error.

## Runtime services

| Service | Inputs | Output / behavior |
|---|---|---|
| config.pub:getValue | packageName, key, optional defaultValue | value from active cache; rejects encrypted values |
| config.pub:getSecret | packageName, key | decrypted value from active cache |
| config.pub:resetServerCache | token | loadedAt, environment; administrator only |
| config.admin:dispatch | action and action-specific fields | result: JSON string; administrator only |
| config.lifecycle:startup | none | initializes cache once and registers menu |
| config.lifecycle:menu | none | name, text, url, target callback fields |
| config.lifecycle:shutdown | none | removes menu; requires Administrators context |

Example Flow INVOKE getValue:
```
packageName = NBKCustomer
key = customer.timeout
```
Map `value` from the service output. Use getSecret for encrypted password keys.
Missing ordinary values raise an error unless defaultValue was supplied.
All runtime reads initially require Administrators. For an application identity,
create a dedicated IS ACL and add the approved identity/group; set JVM property
`-Dconfig.runtimeAcl=YourConfigReaderACL` and change config.pub Execute ACL
accordingly. getValue/getSecret both check this ACL even on internal invokes;
resetServerCache always checks Administrators. This grants package-wide reads:
there is no per-package reader authorization in v1. Do not use an Everyone ACL.

For Designer/API reset, first call dispatch with action=status, parse result JSON
and obtain token. Map token to resetServerCache, or use dispatch action=reset.
Tokens are bound to authenticated username and JVM, expire after 30 minutes and
become invalid on package reload. Refresh status in the browser for a new token.

## Encrypted values

Generate a random master key using your JDK (this prints a NEW key; store securely):
```
java -cp config/code/jars/config-manager.jar nbk.config.ConfigStore
```
Run from the delivery root, or adjust the JAR path after installation.

Store the generated Base64 text as a single line in an OS-protected file OUTSIDE
all package directories; grant read permission only to the IS service account
(and authorized administrators). Back it up separately from the packages.
Set IS JVM property, then restart using the normal JVM wrapper configuration:
```
-Dconfig.masterKeyFile=C:/IS-secrets/config-master.key
```
Linux example: `-Dconfig.masterKeyFile=/etc/is-secrets/config-master.key`.
Alternatively supply CONFIG_MASTER_KEY in the IS process environment before
startup. The environment value takes precedence. Do not put the key in a .cnf file,
source control, this delivery, shell history or the browser. Never use the dummy
all-zero key from the automated test fixtures in a real environment.

In the UI open the desired file > Store an encrypted value > key + new secret >
Encrypt and save. This writes ciphertext only; Reset Server Cache activates it.
Format: `ENCv1:<Base64 12-byte IV>:<Base64 ciphertext+GCM tag>`.
Ciphertext is authenticated against the package name AND property key; moving it
to another package/key requires decrypting and re-encrypting in a trusted process.
A fresh random IV is generated on every encryption. Existing original WxConfig
ciphertext is NOT supported; re-enter secrets with authorized access.

Use the same protected key on nodes that must decrypt the same configuration.
No key rotation UI is supplied; do not replace the key until all encrypted values
have been re-encrypted through a planned migration. Loss of the key loses access
to encrypted values. Secret plaintext is transiently present in Java Strings,
HTTP input and consumer pipelines; Java Strings cannot reliably be zeroized.
Disable pipeline/request-body logging for secret operations; v1 has no HSM/Vault
integration. Property keys cannot start with # or ! unless properly escaped by
Properties.store, which encrypt-and-save handles.

## Required smoke test on your IS

1. Confirm Configuration menu and authenticated UI load; anonymous/non-admin
   requests must be denied. Verify user/group ACL mapping with your identity store.
2. Invoke getValue(config, demo.timeout): 30000.
3. Change demo.timeout to 60000, Save. Invoke getValue: still 30000.
4. Reset Server Cache. Invoke getValue: 60000.
5. Restart the development IS through its normal procedure. getValue: 60000.
6. Set environment=uat on disk; reset. demo.message: Hello from UAT.
7. Provision master key. Encrypt/save demo.password. It must be ciphertext on disk.
   Before reset the new key is unavailable; after reset getSecret returns its value.
   getValue for demo.password must reject it.
8. Open the same file in two browser tabs; save in one then save in the other.
   The stale save must be rejected.
9. Tamper with a file name/package to attempt traversal. It must be rejected.
10. Verify a non-administrator cannot read/edit files or reset the cache. Verify
    a configured application reader can look up values but cannot use admin APIs.

Do not progress to production until these pass. A cached value already copied
into an existing JDBC/JMS connection or another component is not automatically
reapplied; that component needs its own controlled reinitialization.

## Multi-node / deployment behavior

Save and reset affect the filesystem and JVM of the IS handling that request.
There is no broadcast, shared database, cluster lock or synchronization. Use a
direct node admin URL rather than a load-balanced URL; deploy the files and reset
on every intended node. Separate keys/environment settings are operational choices.
Changing a package's files independently of this UI also requires reset.
Package reload recreates the classloader and startup snapshot. A direct call to
startup while already initialized registers the menu but does not reset the cache.

## Build and test

`python3 rebuild.py <IS-installation-root> <JDK-home>` compiles against real jars
found under the IS installation root (include the suite root if common/lib is
outside IntegrationServer). Test in development first. No proprietary jars ship.

Tests are executable Java mains; run using your JDK:
```
javac --release 11 -encoding UTF-8 -d test-classes config/code/source/nbk/config/ConfigStore.java tests/ConfigStoreTest.java
```
Set CONFIG_MASTER_KEY to a test-only 32-byte Base64 key and run:
`java -cp test-classes ConfigStoreTest`.

The separate simulated-boundary test compiles the files in tests/fixtures together
with sources; never copy those fixtures into an IS installation or the package JAR.
See TEST_RESULTS.md for actual checks performed here.

## References consulted

- IBM Java service contract (IData, public static method):
  https://www.ibm.com/docs/en/webmethods-integration/wm-integration-server/12.1.0?topic=guide-building-java-services
- IBM package manifest:
  https://www.ibm.com/docs/en/webmethods-integration/wm-integration-server/11.1.0?topic=information-manifest-file
- IBM open package layout/namespace examples:
  https://github.com/IBM/WxMCPServer
- IS ACL API example (must validate on target release):
  https://community.ibm.com/community/user/discussion/how-to-check-a-userid-for-acl-membership?hlmlt=VT

## Scope boundaries

No original WxConfig license/source/code is bundled. No automatic JDBC/JMS/UM
resource provisioning, cluster propagation, secret rotation, original ciphertext
migration, external vault, configuration includes or expression evaluation.
This package never modifies server.cnf, wrapper files, ACL maps or other packages'
startup services. Administrative audit lines contain user/action/package/file only,
not configuration values. Existing package content is changed only on explicit Save.
