"""Rebuild using the target installation's real IS API jars. Never uses fixtures."""
from pathlib import Path
import sys,subprocess,zipfile,os,tempfile
if len(sys.argv)!=3:raise SystemExit('Usage: python rebuild.py <IS/suite-installation-root> <JDK-home>')
base=Path(__file__).resolve().parent
install,jdk=map(lambda s:Path(s).resolve(),sys.argv[1:])
javac=jdk/'bin'/('javac.exe' if os.name=='nt' else 'javac')
jars=[str(p) for p in install.rglob('*.jar') if p.name!='config-manager.jar']
if not jars:raise SystemExit('No IS jars found; specify the suite installation root')
with tempfile.TemporaryDirectory() as tmp:
 target=Path(tmp)/'classes';target.mkdir()
 args=['--release','11','-encoding','UTF-8','-cp',os.pathsep.join(jars),'-d',str(target)]+[str(p) for p in (base/'config/code/source').rglob('*.java')]
 argfile=Path(tmp)/'javac.args';argfile.write_text('\n'.join('"'+x.replace('\\','/').replace('"','\\"')+'"' for x in args),encoding='utf-8')
 subprocess.run([str(javac),'@'+str(argfile)],check=True)
 jar=base/'config/code/jars/config-manager.jar'
 with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
  for p in target.rglob('*.class'):z.write(p,p.relative_to(target))
 print('Rebuilt',jar,'against actual IS jars. Reload config on the development IS.')
