<?xml version='1.0' encoding='utf-8'?>
<Values version="2.0">
  <value name="name">resetServerCache</value>
  <value name="encodeutf8">true</value>
  <value name="body">bmJrLmNvbmZpZy5JU1NlcnZpY2VzLnJlc2V0U2VydmVyQ2FjaGUocGlwZWxpbmUpOw==</value>
</Values>