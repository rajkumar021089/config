<?xml version='1.0' encoding='utf-8'?>
<Values version="2.0">
  <value name="name">menu</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gbWVudTogYWN0dWFsIHNlcnZpY2UgbG9naWM7IHNoYXJlZCBtZXRob2RzIGFyZSB2aXNpYmxlIGluIERlc2lnbmVyLgpvdXRwdXQocGlwZWxpbmUsICJuYW1lIiwgImNvbmZpZyIpOwogICAgb3V0cHV0KHBpcGVsaW5lLCAidGV4dCIsICJDb25maWd1cmF0aW9uIik7CiAgICBvdXRwdXQocGlwZWxpbmUsICJ1cmwiLCAiLi4vY29uZmlnL2luZGV4Lmh0bWwiKTsKICAgIG91dHB1dChwaXBlbGluZSwgInRhcmdldCIsICJjb25maWdDb25zb2xlIik7Cg==</value>
</Values>