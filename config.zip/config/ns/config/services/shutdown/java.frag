<?xml version='1.0' encoding='utf-8'?>
<Values version="2.0">
  <value name="name">shutdown</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gc2h1dGRvd246IGFjdHVhbCBzZXJ2aWNlIGxvZ2ljOyBzaGFyZWQgbWV0aG9kcyBhcmUgdmlzaWJsZSBpbiBEZXNpZ25lci4KdHJ5IHsKICAgICAgYXV0aG9yaXplKCJBZG1pbmlzdHJhdG9ycyIpOwogICAgICBtZW51KGZhbHNlKTsKICAgIH0gY2F0Y2ggKEV4Y2VwdGlvbiBlKSB7CiAgICAgIHRocm93IGVycm9yKGUpOwogICAgfQo=</value>
</Values>