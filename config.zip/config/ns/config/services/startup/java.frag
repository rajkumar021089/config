<?xml version='1.0' encoding='utf-8'?>
<Values version="2.0">
  <value name="name">startup</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gc3RhcnR1cDogYWN0dWFsIHNlcnZpY2UgbG9naWM7IHNoYXJlZCBtZXRob2RzIGFyZSB2aXNpYmxlIGluIERlc2lnbmVyLgp0cnkgewogICAgICBzdG9yZSgpOwogICAgICB0cnkgewogICAgICAgIG1lbnUodHJ1ZSk7CiAgICAgIH0gY2F0Y2ggKEV4Y2VwdGlvbiBlKSB7CiAgICAgICAgU3lzdGVtLmVyci5wcmludGxuKCJjb25maWc6IG1lbnUgcmVnaXN0cmF0aW9uIHVuYXZhaWxhYmxlOyB1c2UgL2NvbmZpZy9pbmRleC5odG1sIik7CiAgICAgIH0KICAgIH0gY2F0Y2ggKEV4Y2VwdGlvbiBlKSB7CiAgICAgIHRocm93IGVycm9yKGUpOwogICAgfQo=</value>
</Values>