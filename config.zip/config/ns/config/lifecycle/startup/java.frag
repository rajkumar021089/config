<?xml version='1.0' encoding='utf-8'?>
<Values version="2.0">
  <value name="name">startup</value>
  <value name="encodeutf8">true</value>
  <value name="body">bmJrLmNvbmZpZy5JU1NlcnZpY2VzLnN0YXJ0dXAocGlwZWxpbmUpOw==</value>
</Values>