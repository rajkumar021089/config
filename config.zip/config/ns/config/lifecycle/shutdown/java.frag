<?xml version='1.0' encoding='utf-8'?>
<Values version="2.0">
  <value name="name">shutdown</value>
  <value name="encodeutf8">true</value>
  <value name="body">bmJrLmNvbmZpZy5JU1NlcnZpY2VzLnNodXRkb3duKHBpcGVsaW5lKTs=</value>
</Values>