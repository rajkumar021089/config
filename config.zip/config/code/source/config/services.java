package config;

import com.wm.app.b2b.server.*;
import com.wm.data.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.time.Instant;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/**
 * Designer-visible configuration manager. Service bodies are exposed in each service Source tab.
 * Shared helpers and ConfigStore are exposed in config.services > Shared > Source. No custom JAR is
 * required. Integration Server compiles this Java into ordinary class files.
 */
public final class services {
  // One cache manager per package classloader / Integration Server JVM.
  private static volatile ConfigStore STORE;
  // Random signing key for short-lived, username-bound browser mutation tokens.
  private static final byte[] TOKEN_KEY = new byte[32];

  static {
    new SecureRandom().nextBytes(TOKEN_KEY);
  }

  /** Read a String from the IData pipeline and always release its cursor. */
  private static String input(IData p, String key) {
    IDataCursor c = p.getCursor();
    try {
      return IDataUtil.getString(c, key);
    } finally {
      c.destroy();
    }
  }

  /** Put one result into the pipeline without retaining an IDataCursor. */
  private static void output(IData p, String key, Object value) {
    IDataCursor c = p.getCursor();
    try {
      IDataUtil.put(c, key, value);
    } finally {
      c.destroy();
    }
  }

  /** Use the authenticated IS identity; never accept a username supplied by the browser. */
  private static String username() throws Exception {
    Object u = Service.getUser();
    if (u == null) throw new SecurityException("Authentication required");
    return String.valueOf(u.getClass().getMethod("getName").invoke(u));
  }

  /** Fail closed unless the current user is allowed by the named IS ACL. */
  private static void authorize(String acl) throws Exception {
    Object user = Service.getUser();
    if (user == null) throw new SecurityException("Authentication required");
    Class<?> mgr = Class.forName("com.wm.app.b2b.server.ACLManager");
    Object group = mgr.getMethod("getGroup", String.class).invoke(null, acl);
    if (group == null) throw new SecurityException("Required ACL is missing");
    for (Method m : mgr.getMethods())
      if (m.getName().equals("allow")
          && m.getParameterCount() == 2
          && m.getParameterTypes()[0].isInstance(group)
          && m.getParameterTypes()[1].isInstance(user)) {
        if (Boolean.TRUE.equals(m.invoke(null, group, user))) return;
        throw new SecurityException("Access denied");
      }
    throw new SecurityException("Unable to validate IS ACL; access denied");
  }

  /** Initialize once. Later disk edits are invisible until resetServerCache runs. */
  private static ConfigStore store() throws Exception {
    ConfigStore s = STORE;
    if (s == null)
      synchronized (services.class) {
        s = STORE;
        if (s == null) {
          String override = System.getProperty("config.packagesRoot");
          Path root;
          if (override != null) root = Paths.get(override);
          else {
            Class<?> server = Class.forName("com.wm.app.b2b.server.Server");
            Object resources = server.getMethod("getResources").invoke(null);
            File dir =
                (File)
                    resources
                        .getClass()
                        .getMethod("getPackageConfigDir", String.class)
                        .invoke(resources, "config");
            root = dir.toPath().getParent().getParent();
          }
          s = new ConfigStore(root);
          s.reset();
          STORE = s;
        }
      }
    return s;
  }

  /** Register/remove the Solutions menu callback through the IS menu services. */
  private static void menu(boolean add) throws Exception {
    IData p = IDataFactory.create();
    output(p, "callback", "config.services:menu");
    Service.doInvoke("wm.server.ui", add ? "addSolution" : "removeSolution", p);
  }

  /** Package startup hook: build the first cache snapshot and register the UI link. */
  public static void startup(IData pipeline) throws ServiceException {
    try {
      store();
      try {
        menu(true);
      } catch (Exception e) {
        System.err.println("config: menu registration unavailable; use /config/index.html");
      }
    } catch (Exception e) {
      throw error(e);
    }
  }

  /** Package shutdown hook: remove the Solutions menu entry. */
  public static void shutdown(IData pipeline) throws ServiceException {
    try {
      authorize("Administrators");
      menu(false);
    } catch (Exception e) {
      throw error(e);
    }
  }

  /** Menu callback: return the label and the package-hosted browser UI URL. */
  public static void menu(IData pipeline) throws ServiceException {
    output(pipeline, "name", "config");
    output(pipeline, "text", "Configuration");
    output(pipeline, "url", "../config/index.html");
    output(pipeline, "target", "configConsole");
  }

  /** Return a non-secret property from the active in-memory configuration. */
  public static void getValue(IData pipeline) throws ServiceException {
    // Check the caller before reading any package configuration.
    try {
      authorize(System.getProperty("config.runtimeAcl", "Administrators"));
      // Read the immutable JVM snapshot. This does not open the .cnf file.
      String value =
          store().get(input(pipeline, "packageName"), input(pipeline, "key"), input(pipeline, "defaultValue"), false);
      // Encrypted properties are rejected by the ordinary getValue operation.
      output(pipeline, "value", value);
    } catch (Exception e) {
      throw error(e);
    }
  }

  /** Retrieve a secret and decrypt it for the authorized caller. */
  public static void getSecret(IData pipeline) throws ServiceException {
    try {
      // Apply the runtime-reader ACL even when another Flow service invokes this internally.
      authorize(System.getProperty("config.runtimeAcl", "Administrators"));
      // The snapshot holds ciphertext. Decrypt only for this authorized retrieval.
      String value = store().get(input(pipeline, "packageName"), input(pipeline, "key"), null, true);
      // Plaintext now exists in the consumer pipeline; do not log/audit the pipeline.
      output(pipeline, "value", value);
    } catch (Exception e) {
      throw error(e);
    }
  }

  /** Explicitly reload disk configuration; Save never calls this service. */
  public static void resetServerCache(IData pipeline) throws ServiceException {
    try {
      authorize("Administrators");
      checkToken(input(pipeline, "token"));
      ConfigStore.Snapshot s = store().reset();
      output(pipeline, "loadedAt", s.loadedAt);
      output(pipeline, "environment", s.environment);
      audit("reset", "-", "-");
    } catch (Exception e) {
      throw error(e);
    }
  }

  /** Convert failures to IS service errors without including secret values. */
  private static ServiceException error(Exception e) {
    return new ServiceException(
        e instanceof SecurityException ? "config: access denied" : "config: " + e.getMessage());
  }

  /** Authenticate browser tokens with HMAC-SHA256; this is separate from data encryption. */
  private static String mac(String data) throws Exception {
    Mac m = Mac.getInstance("HmacSHA256");
    m.init(new SecretKeySpec(TOKEN_KEY, "HmacSHA256"));
    return Base64.getUrlEncoder()
        .withoutPadding()
        .encodeToString(m.doFinal(data.getBytes(StandardCharsets.UTF_8)));
  }

  /** Issue a token bound to the current username and this JVM signing key. */
  private static String token() throws Exception {
    String t = Long.toString(System.currentTimeMillis());
    return t + "." + mac(username() + "\n" + t);
  }

  /** Reject missing, changed or expired tokens before changing files or cache. */
  private static void checkToken(String token) throws Exception {
    if (token == null) throw new SecurityException();
    String[] v = token.split("\\.", -1);
    if (v.length != 2) throw new SecurityException();
    long age = System.currentTimeMillis() - Long.parseLong(v[0]);
    if (age < 0
        || age > 1800000
        || !MessageDigest.isEqual(
            mac(username() + "\n" + v[0]).getBytes(StandardCharsets.US_ASCII),
            v[1].getBytes(StandardCharsets.US_ASCII))) throw new SecurityException();
  }

  /** Audit metadata only: never write configuration values or passwords to the log. */
  private static void audit(String action, String pkg, String file) throws Exception {
    System.out.println(
        "config audit user="
            + username().replaceAll("[\\r\\n]", "_")
            + " action="
            + action
            + " package="
            + pkg
            + " file="
            + file);
  }

  /** Escape a String as JSON without adding an external JSON library. */
  private static String q(String s) {
    if (s == null) return "null";
    StringBuilder b = new StringBuilder("\"");
    for (char c : s.toCharArray()) {
      if (c == '"' || c == '\\') b.append('\\').append(c);
      else if (c < 32) b.append(String.format("\\u%04x", (int) c));
      else b.append(c);
    }
    return b.append('"').toString();
  }

  /** Serialize package/file names into a JSON array for the browser. */
  private static String array(List<String> a) {
    StringJoiner j = new StringJoiner(",", "[", "]");
    for (String s : a) j.add(q(s));
    return j.toString();
  }

  /** Browser endpoint: list/read/save files and explicitly reset the active cache. */
  public static void dispatch(IData pipeline) throws ServiceException {
    try {
      authorize("Administrators");
      ConfigStore s = store();
      String action = input(pipeline, "action"),
          pkg = input(pipeline, "packageName"),
          file = input(pipeline, "fileName");
      String result;
      if (action == null || action.equals("status")) {
        ConfigStore.Snapshot snap = s.snapshot();
        result =
            "{\"token\":"
                + q(token())
                + ",\"environment\":"
                + q(snap.environment)
                + ",\"loadedAt\":"
                + q(snap.loadedAt)
                + ",\"packages\":"
                + array(s.listPackages())
                + "}";
      } else if (action.equals("files")) {
        result = "{\"files\":" + array(s.listFiles(pkg)) + "}";
      } else if (action.equals("read")) {
        String text = s.read(pkg, file);
        result = "{\"content\":" + q(text) + ",\"version\":" + q(ConfigStore.hash(text)) + "}";
      } else {
        // Reading is allowed after admin authorization. Mutations also require a CSRF token.
        checkToken(input(pipeline, "token"));
        switch (action) {
          // SAVE changes disk only. No snapshot assignment and no reset() call here.
          case "save":
            {
              String version = s.save(pkg, file, input(pipeline, "content"), input(pipeline, "version"));
              audit("save", pkg, file);
              result =
                  "{\"message\":\"Saved to disk. Active cache unchanged.\",\"version\":"
                      + q(version)
                      + "}";
              break;
            }
          // Encrypt before persisting; plaintext is removed from the output pipeline.
          case "saveSecret":
            {
              String text = s.read(pkg, file), key = input(pipeline, "key"), plain = input(pipeline, "secret");
              Properties values = new Properties();
              values.load(new StringReader(text));
              values.setProperty(key, s.encrypt(pkg, key, plain));
              StringWriter writer = new StringWriter();
              values.store(writer, "config: encrypted value updated; reset cache to activate");
              String version = s.save(pkg, file, writer.toString(), input(pipeline, "version"));
              output(pipeline, "secret", null);
              audit("saveSecret", pkg, file);
              result =
                  "{\"message\":\"Encrypted value saved. Active cache unchanged. Reopen"
                      + " file.\",\"version\":"
                      + q(version)
                      + "}";
              break;
            }
          // RESET builds a complete replacement snapshot before publishing it.
          case "reset":
            {
              ConfigStore.Snapshot snap = s.reset();
              audit("reset", "-", "-");
              result =
                  "{\"message\":\"Server cache refreshed\",\"loadedAt\":"
                      + q(snap.loadedAt)
                      + ",\"environment\":"
                      + q(snap.environment)
                      + "}";
              break;
            }
          case "create":
            {
              String version = s.save(pkg, file, "# Package configuration\n", "NEW");
              audit("create", pkg, file);
              result =
                  "{\"message\":\"File created. Cache unchanged.\",\"version\":" + q(version) + "}";
              break;
            }
          default:
            throw new IllegalArgumentException("Unknown action");
        }
      }
      output(pipeline, "result", result);
    } catch (Exception e) {
      output(pipeline, "secret", null);
      if (e instanceof SecurityException) throw error(e);
      output(
          pipeline,
          "result",
          "{\"error\":"
              + q(e.getMessage() == null ? "Configuration operation failed" : e.getMessage())
              + "}");
    }
  }

  // Shared configuration engine; visible in the Designer Shared Source tab.
  public static final class ConfigStore {
    public static final String PREFIX = "ENCv1:";
    private final Path root;
    // Volatile publishes a whole immutable configuration snapshot to all service threads.
    private volatile Snapshot snapshot;
    private static final SecureRandom RANDOM = new SecureRandom();

    /** Active environment, load timestamp and package-scoped cached key/value maps. */
    public static final class Snapshot {
      public final String environment, loadedAt;
      public final Map<String, Map<String, String>> packages;

      Snapshot(String env, Map<String, Map<String, String>> values) {
        environment = env;
        loadedAt = Instant.now().toString();
        packages = Collections.unmodifiableMap(values);
      }
    }

    public ConfigStore(Path packagesRoot) throws IOException {
      root = packagesRoot.toRealPath();
    }

    public Path root() {
      return root;
    }

    /** Reject traversal and unexpected path characters before accessing package directories. */
    private static String name(String s) {
      if (s == null || !s.matches("[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}") || s.contains(".."))
        throw new IllegalArgumentException("Invalid package/environment name");
      return s;
    }

    /** Accept only real installed package directories under the configured packages root. */
    private Path packageDir(String pkg) throws IOException {
      Path p = root.resolve(name(pkg));
      if (Files.isSymbolicLink(p)
          || !Files.isDirectory(p)
          || !Files.isRegularFile(p.resolve("manifest.v3")))
        throw new IOException("Unknown package");
      if (!p.toRealPath().getParent().equals(root)) throw new IOException("Package path rejected");
      return p;
    }

    /** Confine all file operations to the selected package config directory. */
    private Path directory(String pkg) throws IOException {
      Path p = packageDir(pkg).resolve("config");
      if (Files.isSymbolicLink(p)
          || !Files.isDirectory(p)
          || !p.toRealPath().getParent().equals(packageDir(pkg).toRealPath()))
        throw new IOException("Configuration directory unavailable");
      return p;
    }

    /** Allow only wxconfig*.cnf filenames; reject arbitrary paths and symbolic links. */
    private Path file(String pkg, String filename) throws IOException {
      if (filename == null || !filename.matches("wxconfig(?:-[A-Za-z0-9_]+)?\\.cnf"))
        throw new IOException("Only wxconfig configuration files are allowed");
      Path p = directory(pkg).resolve(filename);
      if (Files.isSymbolicLink(p)) throw new IOException("Symbolic links are not allowed");
      if (Files.exists(p) && !Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS))
        throw new IOException("Not a regular file");
      return p;
    }

    /** Enumerate on-disk packages; a manifest.v3 identifies a package directory. */
    public List<String> listPackages() throws IOException {
      List<String> out = new ArrayList<>();
      try (DirectoryStream<Path> ds = Files.newDirectoryStream(root)) {
        for (Path p : ds)
          try {
            packageDir(p.getFileName().toString());
            out.add(p.getFileName().toString());
          } catch (Exception ignored) {
          }
      }
      Collections.sort(out);
      return out;
    }

    /** List supported configuration files without loading them into the runtime cache. */
    public List<String> listFiles(String pkg) throws IOException {
      List<String> out = new ArrayList<>();
      Path d = packageDir(pkg).resolve("config");
      if (!Files.exists(d)) return out;
      directory(pkg);
      try (DirectoryStream<Path> ds = Files.newDirectoryStream(d, "wxconfig*.cnf")) {
        for (Path p : ds)
          try {
            file(pkg, p.getFileName().toString());
            if (Files.isRegularFile(p)) out.add(p.getFileName().toString());
          } catch (Exception ignored) {
          }
      }
      Collections.sort(out);
      return out;
    }

    /** Parse UTF-8 text with Java properties syntax and enforce the file size limit. */
    private static Properties parse(String text) throws IOException {
      if (text.length() > 1048576) throw new IOException("Maximum file size is 1 MiB");
      Properties p = new Properties();
      try {
        p.load(new StringReader(text));
      } catch (IllegalArgumentException e) {
        throw new IOException("Invalid properties syntax");
      }
      return p;
    }

    /** Read disk content for the editor. This deliberately leaves the JVM snapshot untouched. */
    public String read(String pkg, String filename) throws IOException {
      Path p = file(pkg, filename);
      if (Files.size(p) > 1048576) throw new IOException("Maximum file size is 1 MiB");
      return Files.readString(p, StandardCharsets.UTF_8);
    }

    /** SHA-256 version token prevents one editor from overwriting another editor changes. */
    public static String hash(String text) throws Exception {
      return Base64.getEncoder()
          .encodeToString(
              MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8)));
    }

    /** Optimistic concurrency check; atomic replace; never touches snapshot. */
    public synchronized String save(String pkg, String filename, String text, String expected)
        throws Exception {
      parse(text);
      Path p = file(pkg, filename);
      String actual = Files.exists(p) ? hash(read(pkg, filename)) : "NEW";
      if (expected == null || !actual.equals(expected))
        throw new IOException("File changed since it was opened. Reopen before saving.");
      Path temp = Files.createTempFile(p.getParent(), ".config-", ".tmp");
      try {
        try {
          Files.setPosixFilePermissions(
              temp, java.nio.file.attribute.PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException ignored) {
        }
        Files.writeString(temp, text, StandardCharsets.UTF_8);
        try {
          Files.move(temp, p, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
          throw new IOException("Filesystem does not support atomic saves", e);
        }
      } finally {
        Files.deleteIfExists(temp);
      }
      return hash(text);
    }

    /** Read common settings, overlay the active environment, then publish atomically. */
    public synchronized Snapshot reset() throws Exception {
      Properties settings =
          parse(
              Files.readString(
                  directory("config").resolve("manager.properties"), StandardCharsets.UTF_8));
      String env = name(settings.getProperty("environment", "dev"));
      Map<String, Map<String, String>> all = new TreeMap<>();
      for (String pkg : listPackages()) {
        Map<String, String> values = new TreeMap<>();
        List<String> names = listFiles(pkg);
        for (String f : Arrays.asList("wxconfig.cnf", "wxconfig-" + env + ".cnf"))
          if (names.contains(f)) {
            Properties p = parse(read(pkg, f));
            for (String k : p.stringPropertyNames()) values.put(k, p.getProperty(k));
          }
        if (!values.isEmpty()) all.put(pkg, Collections.unmodifiableMap(values));
      }
      // Do not publish until EVERY file parses successfully. A failed reset preserves the old
      // cache.
      Snapshot next = new Snapshot(env, all);
      snapshot = next;
      return next;
    }

    /** Return the currently published snapshot, never a partially constructed map. */
    public Snapshot snapshot() {
      Snapshot s = snapshot;
      if (s == null) throw new IllegalStateException("Cache not initialized; run startup/reset");
      return s;
    }

    /** Lookup reads only memory. Encrypted values require the secret-aware API. */
    public String get(String pkg, String key, String fallback, boolean decrypt) throws Exception {
      Map<String, String> p = snapshot().packages.get(pkg);
      String v = p == null ? null : p.get(key);
      if (v == null) {
        if (fallback != null) return fallback;
        throw new IllegalArgumentException("Configuration key not found");
      }
      if (v.startsWith(PREFIX)) {
        if (!decrypt) throw new IllegalArgumentException("Encrypted key: use getSecret");
        return decrypt(pkg, key, v);
      }
      return v;
    }

    /** Read the 256-bit key from the process environment or a protected external file. */
    private SecretKeySpec masterKey() throws Exception {
      String encoded = System.getenv("CONFIG_MASTER_KEY");
      if (encoded == null || encoded.isBlank()) {
        String f = System.getProperty("config.masterKeyFile");
        if (f == null)
          throw new IllegalStateException("Set CONFIG_MASTER_KEY or config.masterKeyFile");
        Path p = Paths.get(f);
        if (!p.isAbsolute() || p.toRealPath().startsWith(root))
          throw new IllegalStateException("Master key file must be absolute and outside packages");
        encoded = Files.readString(p, StandardCharsets.US_ASCII).trim();
      }
      byte[] bytes = Base64.getDecoder().decode(encoded);
      if (bytes.length != 32)
        throw new IllegalArgumentException("Master key must contain 32 bytes encoded as Base64");
      return new SecretKeySpec(bytes, "AES");
    }

    /** AES-GCM uses a fresh nonce and binds ciphertext to its package and property key. */
    public String encrypt(String pkg, String key, String plain) throws Exception {
      packageDir(pkg);
      if (key == null || key.isBlank() || plain == null)
        throw new IllegalArgumentException("Key/value required");
      byte[] iv = new byte[12];
      RANDOM.nextBytes(iv);
      Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
      c.init(Cipher.ENCRYPT_MODE, masterKey(), new GCMParameterSpec(128, iv));
      c.updateAAD((pkg + "\n" + key).getBytes(StandardCharsets.UTF_8));
      return PREFIX
          + Base64.getEncoder().encodeToString(iv)
          + ":"
          + Base64.getEncoder().encodeToString(c.doFinal(plain.getBytes(StandardCharsets.UTF_8)));
    }

    /** Authenticate/decrypt on retrieval; reject tampering, wrong keys and moved ciphertext. */
    private String decrypt(String pkg, String key, String value) throws Exception {
      try {
        String[] parts = value.substring(PREFIX.length()).split(":", -1);
        if (parts.length != 2) throw new GeneralSecurityException();
        byte[] iv = Base64.getDecoder().decode(parts[0]);
        if (iv.length != 12) throw new GeneralSecurityException();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, masterKey(), new GCMParameterSpec(128, iv));
        c.updateAAD((pkg + "\n" + key).getBytes(StandardCharsets.UTF_8));
        return new String(c.doFinal(Base64.getDecoder().decode(parts[1])), StandardCharsets.UTF_8);
      } catch (Exception e) {
        throw new GeneralSecurityException(
            "Unable to decrypt configuration value; check key and package/key context");
      }
    }
  }
}
