package config;
import com.wm.data.IData;
import com.wm.app.b2b.server.ServiceException;
public final class lifecycle {
 public static void startup(IData pipeline) throws ServiceException {nbk.config.ISServices.startup(pipeline);}
 public static void shutdown(IData pipeline) throws ServiceException {nbk.config.ISServices.shutdown(pipeline);}
 public static void menu(IData pipeline) throws ServiceException {nbk.config.ISServices.menu(pipeline);}
}
