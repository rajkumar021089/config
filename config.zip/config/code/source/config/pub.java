package config;
import com.wm.data.IData;
import com.wm.app.b2b.server.ServiceException;
public final class pub {
 public static void getValue(IData pipeline) throws ServiceException {nbk.config.ISServices.getValue(pipeline);}
 public static void getSecret(IData pipeline) throws ServiceException {nbk.config.ISServices.getSecret(pipeline);}
 public static void resetServerCache(IData pipeline) throws ServiceException {nbk.config.ISServices.resetServerCache(pipeline);}
}
