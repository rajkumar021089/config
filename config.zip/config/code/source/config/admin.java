package config;
import com.wm.data.IData;
import com.wm.app.b2b.server.ServiceException;
public final class admin {
 public static void dispatch(IData pipeline) throws ServiceException {nbk.config.ISServices.dispatch(pipeline);}
}
