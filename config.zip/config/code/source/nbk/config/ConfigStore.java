package nbk.config;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.time.Instant;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/** Independent configuration engine. File edits and published cache are intentionally separate. */
public final class ConfigStore {
 public static final String PREFIX="ENCv1:";
 private final Path root;
 private volatile Snapshot snapshot;
 private static final SecureRandom RANDOM=new SecureRandom();
 public static final class Snapshot {
  public final String environment, loadedAt;
  public final Map<String,Map<String,String>> packages;
  Snapshot(String env, Map<String,Map<String,String>> values) {
   environment=env; loadedAt=Instant.now().toString(); packages=Collections.unmodifiableMap(values);
  }
 }
 public ConfigStore(Path packagesRoot) throws IOException {root=packagesRoot.toRealPath();}
 public Path root(){return root;}
 private static String name(String s) {
  if(s==null || !s.matches("[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}") || s.contains(".."))
   throw new IllegalArgumentException("Invalid package/environment name");
  return s;
 }
 private Path packageDir(String pkg) throws IOException {
  Path p=root.resolve(name(pkg));
  if(Files.isSymbolicLink(p)||!Files.isDirectory(p)||!Files.isRegularFile(p.resolve("manifest.v3"))) throw new IOException("Unknown package");
  if(!p.toRealPath().getParent().equals(root))throw new IOException("Package path rejected"); return p;
 }
 private Path directory(String pkg) throws IOException {
  Path p=packageDir(pkg).resolve("config");
  if(Files.isSymbolicLink(p)||!Files.isDirectory(p)||!p.toRealPath().getParent().equals(packageDir(pkg).toRealPath()))throw new IOException("Configuration directory unavailable");return p;
 }
 private Path file(String pkg,String filename) throws IOException {
  if(filename==null||!filename.matches("wxconfig(?:-[A-Za-z0-9_]+)?\\.cnf"))throw new IOException("Only wxconfig configuration files are allowed");
  Path p=directory(pkg).resolve(filename);
  if(Files.isSymbolicLink(p))throw new IOException("Symbolic links are not allowed");
  if(Files.exists(p)&&!Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS))throw new IOException("Not a regular file");return p;
 }
 public List<String> listPackages() throws IOException {
  List<String> out=new ArrayList<>(); try(DirectoryStream<Path> ds=Files.newDirectoryStream(root)){
   for(Path p:ds)try{packageDir(p.getFileName().toString());out.add(p.getFileName().toString());}catch(Exception ignored){}
  } Collections.sort(out);return out;
 }
 public List<String> listFiles(String pkg) throws IOException {
  List<String> out=new ArrayList<>(); Path d=packageDir(pkg).resolve("config");if(!Files.exists(d))return out;
  directory(pkg);try(DirectoryStream<Path> ds=Files.newDirectoryStream(d,"wxconfig*.cnf")){
   for(Path p:ds)try{file(pkg,p.getFileName().toString());if(Files.isRegularFile(p))out.add(p.getFileName().toString());}catch(Exception ignored){}
  } Collections.sort(out);return out;
 }
 private static Properties parse(String text) throws IOException {
  if(text.length()>1048576)throw new IOException("Maximum file size is 1 MiB");
  Properties p=new Properties();try{p.load(new StringReader(text));}catch(IllegalArgumentException e){throw new IOException("Invalid properties syntax");}return p;
 }
 public String read(String pkg,String filename) throws IOException {
  Path p=file(pkg,filename);if(Files.size(p)>1048576)throw new IOException("Maximum file size is 1 MiB");return Files.readString(p,StandardCharsets.UTF_8);
 }
 public static String hash(String text) throws Exception {
  return Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8)));
 }
 /** Optimistic concurrency check; atomic replace; never touches snapshot. */
 public synchronized String save(String pkg,String filename,String text,String expected) throws Exception {
  parse(text);Path p=file(pkg,filename);String actual=Files.exists(p)?hash(read(pkg,filename)):"NEW";
  if(expected==null||!actual.equals(expected))throw new IOException("File changed since it was opened. Reopen before saving.");
  Path temp=Files.createTempFile(p.getParent(),".config-",".tmp");
  try {
   try{Files.setPosixFilePermissions(temp,java.nio.file.attribute.PosixFilePermissions.fromString("rw-------"));}catch(UnsupportedOperationException ignored){}
   Files.writeString(temp,text,StandardCharsets.UTF_8);
   try{Files.move(temp,p,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){throw new IOException("Filesystem does not support atomic saves",e);}
  }finally{Files.deleteIfExists(temp);}return hash(text);
 }
 public synchronized Snapshot reset() throws Exception {
  Properties settings=parse(Files.readString(directory("config").resolve("manager.properties"),StandardCharsets.UTF_8));
  String env=name(settings.getProperty("environment","dev"));
  Map<String,Map<String,String>> all=new TreeMap<>();
  for(String pkg:listPackages()){
   Map<String,String> values=new TreeMap<>();List<String> names=listFiles(pkg);
   for(String f:Arrays.asList("wxconfig.cnf","wxconfig-"+env+".cnf"))if(names.contains(f)){
    Properties p=parse(read(pkg,f));for(String k:p.stringPropertyNames())values.put(k,p.getProperty(k));
   }
   if(!values.isEmpty())all.put(pkg,Collections.unmodifiableMap(values));
  }
  Snapshot next=new Snapshot(env,all);snapshot=next;return next;
 }
 public Snapshot snapshot(){Snapshot s=snapshot;if(s==null)throw new IllegalStateException("Cache not initialized; run startup/reset");return s;}
 public String get(String pkg,String key,String fallback,boolean decrypt) throws Exception {
  Map<String,String> p=snapshot().packages.get(pkg);String v=p==null?null:p.get(key);
  if(v==null){if(fallback!=null)return fallback;throw new IllegalArgumentException("Configuration key not found");}
  if(v.startsWith(PREFIX)){if(!decrypt)throw new IllegalArgumentException("Encrypted key: use getSecret");return decrypt(pkg,key,v);}return v;
 }
 private SecretKeySpec masterKey() throws Exception {
  String encoded=System.getenv("CONFIG_MASTER_KEY");
  if(encoded==null||encoded.isBlank()){
   String f=System.getProperty("config.masterKeyFile");if(f==null)throw new IllegalStateException("Set CONFIG_MASTER_KEY or config.masterKeyFile");
   Path p=Paths.get(f);if(!p.isAbsolute()||p.toRealPath().startsWith(root))throw new IllegalStateException("Master key file must be absolute and outside packages");encoded=Files.readString(p,StandardCharsets.US_ASCII).trim();
  }
  byte[] bytes=Base64.getDecoder().decode(encoded);if(bytes.length!=32)throw new IllegalArgumentException("Master key must contain 32 bytes encoded as Base64");return new SecretKeySpec(bytes,"AES");
 }
 public String encrypt(String pkg,String key,String plain) throws Exception {
  packageDir(pkg);if(key==null||key.isBlank()||plain==null)throw new IllegalArgumentException("Key/value required");
  byte[] iv=new byte[12];RANDOM.nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,masterKey(),new GCMParameterSpec(128,iv));c.updateAAD((pkg+"\n"+key).getBytes(StandardCharsets.UTF_8));
  return PREFIX+Base64.getEncoder().encodeToString(iv)+":"+Base64.getEncoder().encodeToString(c.doFinal(plain.getBytes(StandardCharsets.UTF_8)));
 }
 private String decrypt(String pkg,String key,String value) throws Exception {
  try{String[] parts=value.substring(PREFIX.length()).split(":",-1);if(parts.length!=2)throw new GeneralSecurityException();byte[] iv=Base64.getDecoder().decode(parts[0]);if(iv.length!=12)throw new GeneralSecurityException();Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,masterKey(),new GCMParameterSpec(128,iv));c.updateAAD((pkg+"\n"+key).getBytes(StandardCharsets.UTF_8));return new String(c.doFinal(Base64.getDecoder().decode(parts[1])),StandardCharsets.UTF_8);}catch(Exception e){throw new GeneralSecurityException("Unable to decrypt configuration value; check key and package/key context");}
 }
 public static void main(String[] args) {
  byte[] key=new byte[32];RANDOM.nextBytes(key);System.out.println(Base64.getEncoder().encodeToString(key));
 }
}
