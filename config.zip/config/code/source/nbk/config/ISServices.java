package nbk.config;
import com.wm.data.*;
import com.wm.app.b2b.server.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.*;

/** IS boundary. Authorization is enforced in code, including internal invokes. */
public final class ISServices {
 private static volatile ConfigStore STORE;
 private static final byte[] TOKEN_KEY=new byte[32];
 static{new SecureRandom().nextBytes(TOKEN_KEY);}
 private static String input(IData p,String key){IDataCursor c=p.getCursor();try{return IDataUtil.getString(c,key);}finally{c.destroy();}}
 private static void output(IData p,String key,Object value){IDataCursor c=p.getCursor();try{IDataUtil.put(c,key,value);}finally{c.destroy();}}
 private static String username() throws Exception {Object u=Service.getUser();if(u==null)throw new SecurityException("Authentication required");return String.valueOf(u.getClass().getMethod("getName").invoke(u));}
 private static void authorize(String acl) throws Exception {
  Object user=Service.getUser();if(user==null)throw new SecurityException("Authentication required");
  Class<?> mgr=Class.forName("com.wm.app.b2b.server.ACLManager");
  Object group=mgr.getMethod("getGroup",String.class).invoke(null,acl);
  if(group==null)throw new SecurityException("Required ACL is missing");
  for(Method m:mgr.getMethods())if(m.getName().equals("allow")&&m.getParameterCount()==2&&m.getParameterTypes()[0].isInstance(group)&&m.getParameterTypes()[1].isInstance(user)){
   if(Boolean.TRUE.equals(m.invoke(null,group,user)))return;throw new SecurityException("Access denied");
  }
  throw new SecurityException("Unable to validate IS ACL; access denied");
 }
 private static ConfigStore store() throws Exception {
  ConfigStore s=STORE;if(s==null)synchronized(ISServices.class){s=STORE;if(s==null){
   String override=System.getProperty("config.packagesRoot");Path root;
   if(override!=null)root=Paths.get(override);else{
    Class<?> server=Class.forName("com.wm.app.b2b.server.Server");Object resources=server.getMethod("getResources").invoke(null);
    File dir=(File)resources.getClass().getMethod("getPackageConfigDir",String.class).invoke(resources,"config");root=dir.toPath().getParent().getParent();
   }
   s=new ConfigStore(root);s.reset();STORE=s;
  }}return s;
 }
 private static void menu(boolean add) throws Exception {
  IData p=IDataFactory.create();output(p,"callback","config.lifecycle:menu");Service.doInvoke("wm.server.ui",add?"addSolution":"removeSolution",p);
 }
 public static void startup(IData p) throws ServiceException {try{store();try{menu(true);}catch(Exception e){System.err.println("config: menu registration unavailable; use /config/index.html");}}catch(Exception e){throw error(e);}}
 public static void shutdown(IData p) throws ServiceException {try{authorize("Administrators");menu(false);}catch(Exception e){throw error(e);}}
 public static void menu(IData p) throws ServiceException {output(p,"name","config");output(p,"text","Configuration");output(p,"url","../config/index.html");output(p,"target","configConsole");}
 public static void getValue(IData p) throws ServiceException {lookup(p,false);}
 public static void getSecret(IData p) throws ServiceException {lookup(p,true);}
 private static void lookup(IData p,boolean secret) throws ServiceException {
  try{authorize(System.getProperty("config.runtimeAcl","Administrators"));String v=store().get(input(p,"packageName"),input(p,"key"),input(p,"defaultValue"),secret);output(p,"value",v);}catch(Exception e){throw error(e);}
 }
 public static void resetServerCache(IData p) throws ServiceException {
  try{authorize("Administrators");checkToken(input(p,"token"));ConfigStore.Snapshot s=store().reset();output(p,"loadedAt",s.loadedAt);output(p,"environment",s.environment);audit("reset","-","-");}catch(Exception e){throw error(e);}
 }
 private static ServiceException error(Exception e){return new ServiceException(e instanceof SecurityException?"config: access denied":"config: "+e.getMessage());}
 private static String mac(String data) throws Exception {Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(TOKEN_KEY,"HmacSHA256"));return Base64.getUrlEncoder().withoutPadding().encodeToString(m.doFinal(data.getBytes(StandardCharsets.UTF_8)));}
 private static String token() throws Exception{String t=Long.toString(System.currentTimeMillis());return t+"."+mac(username()+"\n"+t);}
 private static void checkToken(String token) throws Exception {
  if(token==null)throw new SecurityException();String[] v=token.split("\\.",-1);if(v.length!=2)throw new SecurityException();long age=System.currentTimeMillis()-Long.parseLong(v[0]);if(age<0||age>1800000||!MessageDigest.isEqual(mac(username()+"\n"+v[0]).getBytes(StandardCharsets.US_ASCII),v[1].getBytes(StandardCharsets.US_ASCII)))throw new SecurityException();
 }
 private static void audit(String action,String pkg,String file)throws Exception{System.out.println("config audit user="+username().replaceAll("[\\r\\n]","_")+" action="+action+" package="+pkg+" file="+file);}
 private static String q(String s){if(s==null)return "null";StringBuilder b=new StringBuilder("\"");for(char c:s.toCharArray()){if(c=='"'||c=='\\')b.append('\\').append(c);else if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}return b.append('"').toString();}
 private static String array(List<String> a){StringJoiner j=new StringJoiner(",","[","]");for(String s:a)j.add(q(s));return j.toString();}
 public static void dispatch(IData p) throws ServiceException {
  try{
   authorize("Administrators");ConfigStore s=store();String action=input(p,"action"),pkg=input(p,"packageName"),file=input(p,"fileName");String result;
   if(action==null||action.equals("status")){
    ConfigStore.Snapshot snap=s.snapshot();result="{\"token\":"+q(token())+",\"environment\":"+q(snap.environment)+",\"loadedAt\":"+q(snap.loadedAt)+",\"packages\":"+array(s.listPackages())+"}";
   }else if(action.equals("files")){result="{\"files\":"+array(s.listFiles(pkg))+"}";
   }else if(action.equals("read")){String text=s.read(pkg,file);result="{\"content\":"+q(text)+",\"version\":"+q(ConfigStore.hash(text))+"}";
   }else{
    checkToken(input(p,"token"));
    switch(action){
     case "save": {String version=s.save(pkg,file,input(p,"content"),input(p,"version"));audit("save",pkg,file);result="{\"message\":\"Saved to disk. Active cache unchanged.\",\"version\":"+q(version)+"}";break;}
     case "saveSecret": {
      String text=s.read(pkg,file),key=input(p,"key"),plain=input(p,"secret");Properties values=new Properties();values.load(new StringReader(text));values.setProperty(key,s.encrypt(pkg,key,plain));StringWriter writer=new StringWriter();values.store(writer,"config: encrypted value updated; reset cache to activate");
      String version=s.save(pkg,file,writer.toString(),input(p,"version"));output(p,"secret",null);audit("saveSecret",pkg,file);result="{\"message\":\"Encrypted value saved. Active cache unchanged. Reopen file.\",\"version\":"+q(version)+"}";break;}
     case "reset":{ConfigStore.Snapshot snap=s.reset();audit("reset","-","-");result="{\"message\":\"Server cache refreshed\",\"loadedAt\":"+q(snap.loadedAt)+",\"environment\":"+q(snap.environment)+"}";break;}
     case "create":{String version=s.save(pkg,file,"# Package configuration\n","NEW");audit("create",pkg,file);result="{\"message\":\"File created. Cache unchanged.\",\"version\":"+q(version)+"}";break;}
     default:throw new IllegalArgumentException("Unknown action");
    }
   }
   output(p,"result",result);
  }catch(Exception e){output(p,"secret",null);if(e instanceof SecurityException)throw error(e);output(p,"result","{\"error\":"+q(e.getMessage()==null?"Configuration operation failed":e.getMessage())+"}");}
 }
}
