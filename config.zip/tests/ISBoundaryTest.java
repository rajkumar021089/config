import com.wm.data.*;import com.wm.app.b2b.server.*;import nbk.config.*;import java.nio.file.*;
public class ISBoundaryTest {
 static int checks;interface Work{void run()throws Exception;}
 static void check(boolean b,String n){if(!b)throw new AssertionError(n);checks++;System.out.println("PASS "+n);}
 static void reject(Work w,String n)throws Exception{try{w.run();}catch(Exception e){check(true,n);return;}throw new AssertionError(n);}
 static IData p(String... args){IData p=IDataFactory.create();for(int i=0;i<args.length;i+=2)IDataUtil.put(p.getCursor(),args[i],args[i+1]);return p;}
 static String result(IData p){return IDataUtil.getString(p.getCursor(),"result");}
 public static void main(String[] a)throws Exception{
  Path root=Files.createTempDirectory("is-boundary-test-");Files.createDirectories(root.resolve("config/config"));Files.writeString(root.resolve("config/manifest.v3"),"test");Files.writeString(root.resolve("config/config/manager.properties"),"environment=dev");Files.writeString(root.resolve("config/config/wxconfig.cnf"),"message=old\n");System.setProperty("config.packagesRoot",root.toString());
  IData status=p("action","status");ISServices.dispatch(status);String out=result(status);check(out.contains("dev"),"admin status allowed");
  String token=out.split("\"token\":\"")[1].split("\"")[0];
  reject(()->ISServices.dispatch(p("action","reset")),"mutation without token denied");
  reject(()->ISServices.dispatch(p("action","reset","token",token+"x")),"tampered token denied");
  Service.user=new User("Anonymous");reject(()->ISServices.dispatch(p("action","status")),"anonymous denied");
  Service.user=new User("Reader");reject(()->ISServices.getSecret(p("packageName","config","key","message")),"unauthorized runtime read denied");
  Service.user=new User("Administrator");String old=Files.readString(root.resolve("config/config/wxconfig.cnf"));
  ISServices.dispatch(p("action","save","token",token,"packageName","config","fileName","wxconfig.cnf","content","message=new\n","version",ConfigStore.hash(old)));
  IData lookup=p("packageName","config","key","message");ISServices.getValue(lookup);check(IDataUtil.getString(lookup.getCursor(),"value").equals("old"),"IS save leaves old cache");
  ISServices.dispatch(p("action","reset","token",token));ISServices.getValue(lookup);check(IDataUtil.getString(lookup.getCursor(),"value").equals("new"),"IS reset activates saved value");
  String current=Files.readString(root.resolve("config/config/wxconfig.cnf"));IData secret=p("action","saveSecret","token",token,"packageName","config","fileName","wxconfig.cnf","key","password","secret","test-password","version",ConfigStore.hash(current));ISServices.dispatch(secret);check(IDataUtil.getString(secret.getCursor(),"secret")==null,"secret removed from output pipeline");check(!Files.readString(root.resolve("config/config/wxconfig.cnf")).contains("test-password"),"IS secret save encrypts file");
  ISServices.dispatch(p("action","reset","token",token));IData pwd=p("packageName","config","key","password");ISServices.getSecret(pwd);check(IDataUtil.getString(pwd.getCursor(),"value").equals("test-password"),"IS secret lookup decrypts");
  System.out.println("TOTAL "+checks+" simulated-boundary checks passed");
 }
}
