import config.services.ConfigStore;
import java.nio.file.*;
import java.util.*;

public class ConfigStoreTest {
  static int checks;

  static void check(boolean value, String name) {
    if (!value) throw new AssertionError(name);
    checks++;
    System.out.println("PASS " + name);
  }

  interface Work {
    void run() throws Exception;
  }

  static void rejected(Work w, String name) throws Exception {
    try {
      w.run();
    } catch (Exception expected) {
      check(true, name);
      return;
    }
    throw new AssertionError(name);
  }

  public static void main(String[] args) throws Exception {
    Path root = Files.createTempDirectory("config-test-");
    for (String pkg : List.of("config", "NBKCustomer")) {
      Files.createDirectories(root.resolve(pkg + "/config"));
      Files.writeString(root.resolve(pkg + "/manifest.v3"), "test");
    }
    Files.writeString(root.resolve("config/config/manager.properties"), "environment=dev\n");
    Files.writeString(
        root.resolve("NBKCustomer/config/wxconfig.cnf"),
        "timeout=30000\ncommon=yes\ntamil=வணக்கம்\n");
    Files.writeString(
        root.resolve("NBKCustomer/config/wxconfig-dev.cnf"), "url=https://dev.example\n");
    ConfigStore s = new ConfigStore(root);
    s.reset();
    check(s.get("NBKCustomer", "timeout", null, false).equals("30000"), "startup loads common");
    check(
        s.get("NBKCustomer", "url", null, false).equals("https://dev.example"),
        "environment file merges");
    check(s.get("NBKCustomer", "tamil", null, false).equals("வணக்கம்"), "UTF-8 survives");
    String before = s.read("NBKCustomer", "wxconfig.cnf"), hash = ConfigStore.hash(before);
    s.save("NBKCustomer", "wxconfig.cnf", "timeout=60000\ncommon=yes\n", hash);
    check(
        s.get("NBKCustomer", "timeout", null, false).equals("30000"), "save does not update cache");
    rejected(() -> s.save("NBKCustomer", "wxconfig.cnf", "timeout=1", hash), "stale edit rejected");
    s.reset();
    check(
        s.get("NBKCustomer", "timeout", null, false).equals("60000"),
        "reset activates saved value");
    ConfigStore restart = new ConfigStore(root);
    restart.reset();
    check(
        restart.get("NBKCustomer", "timeout", null, false).equals("60000"),
        "restart reloads saved value");
    rejected(() -> s.read("../NBKCustomer", "wxconfig.cnf"), "package traversal rejected");
    rejected(() -> s.read("NBKCustomer", "../../server.cnf"), "file traversal rejected");
    rejected(() -> s.read("NBKCustomer", "passman.cnf"), "unrelated config file rejected");
    Path external = Files.createTempFile("config-secret-", ".cnf");
    Files.createSymbolicLink(root.resolve("NBKCustomer/config/wxconfig-evil.cnf"), external);
    rejected(() -> s.read("NBKCustomer", "wxconfig-evil.cnf"), "symlink rejected");
    String cipher = s.encrypt("NBKCustomer", "password", "Secret-for-test");
    check(cipher.startsWith("ENCv1:") && !cipher.contains("Secret-for-test"), "secret encrypted");
    check(
        !cipher.equals(s.encrypt("NBKCustomer", "password", "Secret-for-test")),
        "fresh nonce each encryption");
    String current = s.read("NBKCustomer", "wxconfig.cnf");
    s.save(
        "NBKCustomer",
        "wxconfig.cnf",
        current + "password=" + cipher + "\n",
        ConfigStore.hash(current));
    s.reset();
    check(
        s.get("NBKCustomer", "password", null, true).equals("Secret-for-test"),
        "secret decrypts on retrieval");
    rejected(
        () -> s.get("NBKCustomer", "password", null, false),
        "ordinary lookup cannot return secret");
    current = s.read("NBKCustomer", "wxconfig.cnf");
    s.save(
        "NBKCustomer",
        "wxconfig.cnf",
        current + "copied=" + cipher + "\n",
        ConfigStore.hash(current));
    s.reset();
    rejected(
        () -> s.get("NBKCustomer", "copied", null, true), "encrypted value bound to property key");
    String snap = s.snapshot().loadedAt;
    Files.writeString(root.resolve("NBKCustomer/config/wxconfig-dev.cnf"), "bad=\\uZZZZ");
    rejected(() -> s.reset(), "invalid file rejects whole reset");
    check(s.snapshot().loadedAt.equals(snap), "failed reset preserves previous snapshot");
    Files.writeString(root.resolve("NBKCustomer/config/wxconfig-dev.cnf"), "timeout=90000\n");
    s.reset();
    check(
        s.get("NBKCustomer", "timeout", null, false).equals("90000"), "environment override wins");
    check(
        s.get("NBKCustomer", "absent", "fallback", false).equals("fallback"),
        "missing key default");
    System.out.println("TOTAL " + checks + " checks passed");
  }
}
