# config 2.2.0
Build: config-2.2.0-20261031

Complete source-only webMethods IS package. All nine Java services and their Designer metadata are included. No custom JAR or compiled classes.

## Install / upgrade
1. Back up the existing server config package. Unzip this archive in a staging folder.
2. On upgrades preserve the ENTIRE existing packages/config/config directory and external master key. Merge staged config/ns, config/code and config/pub into the installed package. Also use the included manifest.v3. Do not overwrite manager settings or secrets with example files.
3. Add/update these properties in packages/config/config/manager.properties:

```properties
packagePrefix=NBK
configurationDirectories=config
commonConfigFiles=wxConfig.cnf,config.cnf
```

Keep your environment/globalPackage/cacheDecryptedSecrets settings. If packages use uppercase Config, set configurationDirectories=Config,config. Multiple matching directories in one package cause an explicit error.
4. Refresh the config package in Designer and compile the Java services under config.services. Open dispatch Source and confirm discoveryJson is called; the shared code is between IS-BEGIN-SHARED-SOURCE-AREA and IS-END-SHARED-SOURCE-AREA inside Source, not a separate tab. Manual paste source is in designer-source.
5. Reload the config package. Press Ctrl+F5 in the DSP.
6. Run config.services:dispatch with action=status. Verify buildId is config-2.2.0-20261031 and packagesRoot identifies the correct instance. Configured folders and filenames are returned too.
7. Run dispatch with action=files and packageName=NBKVIsaServices. The result returns files, searchedDirectories and existingDirectories. Verify the search path matches your actual Linux folder. No file contents or secrets appear in diagnostics.
8. Use Reload Configuration on each IS node, and check a nonsecret known key using getValue. Files already present at configured locations load at startup/reload without migration. Save writes disk only.

## Included UI changes
Package/file discovery follows manager properties. All matching packages lists existing common configuration files. Save closes the editor and scrolls to success only after a successful server save. Combined reload validates/publishes configuration then clears IS service-result caches on this node. The standard IBM Admin button is unchanged. Server Cache shows build and discovery metadata.

## Encryption / limits
Original WxConfig [[encrypted:handle]] references require migration into the new encrypted store; this package cannot decode an unknown legacy store. Unresolved encrypted handles do not block ordinary values. Their plaintext lookup fails until manually configured. Malformed references and invalid ciphertext still reject activation. Configure the external master key before migration. Existing 9-field getValue input / propertyValue output contract is retained; excluded interpolation behavior is documented in the reference guide.

## Validation
83 simulated IS checks passed, including configurable arbitrary paths and filenames, exact Config/wxConfig.cnf paths, reload, cached lookups, encryption, migration, concurrency and build/path diagnostics. Java release-11 compilation and JS syntax checked. Actual IS deployment and throughput testing remain necessary.

## Git workflow
Replace the old ZIP in your repository with this archive. Or extract and commit the full source tree if preferred. git diff --stat may be empty for newly untracked files; git status --short shows them. Git pull transfers repository files; it does not itself install or compile an IS package.

## Manual secrets (no migration required)
Do not run the migration tool if entering secrets manually. Existing references remain unchanged and are listed by package on Encrypted Values with Missing - add manually status. Select Open file, View / Edit the configuration file, expand Add / update encrypted value, enter the exact property key and handle, and type the secret. Encrypt and save writes the marker and encrypted store; Reload Configuration activates it. Keep your master key configured externally. No original WxConfig secret is read automatically. Entries remain in their owning package; the Encrypted Values page is the separate inventory.
