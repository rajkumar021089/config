# Combined DSP reset action

Updates the existing working config v2 DSP button to:
**Reload Configuration + Reset Service Cache**.

Order:
1. Read, validate and publish the saved configuration on this node.
2. Invoke pub.cache.serviceResults:resetServerCache to clear IS service results.

If step 1 fails, step 2 is not invoked and the old configuration remains active.
If step 2 fails, the new configuration remains active and the DSP reports partial
success. The response includes configurationReloaded and serviceResultsReset flags.
Clearing service-result caches can cause their next invocations to execute again;
this is an explicit administrative action, not part of each configuration lookup.

## Install on the existing working package

1. Back up the installed config package outside the packages directory.
2. Copy this patch's config/pub files over the installed config/pub files.
3. Copy config/ns/config/services/dispatch/java.frag over the installed matching
   file, refresh Designer, open config.services:dispatch and Ctrl+S to compile.
   Or paste designer-source/dispatch.java.txt into that service's Source body and
   save/compile it. No Shared Source changes are needed for this patch.
4. The service must show a new `case "resetAll"` block. Keep its existing admin ACL.
5. Refresh the DSP with Ctrl+F5. If an old token is rejected after compilation,
   reload the page to get a fresh token.
6. Save a harmless demo.timeout change, use the new combined button and verify
   getValue returns the saved value. The completion message reports both results.

The included code/source/config/services.java is an updated readable source mirror;
it is optional when applying through Designer. It uses the original v2 layout, not
the separate earlier experimental cache-owner patch. Your confirmed working DSP
reload does not require that experimental patch. Do not combine source layouts.

No config/config directory is included, so saved values, environment settings and
secret stores are not overwritten. No business wrapper changes are required.
The standard IBM Administrator button and all IBM/WmRoot services remain unchanged.
Only the DSP button calls the two operations. Execute on each intended node via a
direct admin URL; it does not propagate to the four-node cluster.

## Validation

58 checks passed against simulated IS APIs, including successful combined reset,
validation failure, partial success and preservation of configuration-only reset.
JavaScript syntax and namespace XML checks passed. Actual IS built-in service ACLs,
cache behavior and browser rendering still need the development-server smoke test.

Save UI update: a successful file Save closes the editor, clears its contents, and scrolls to the success message. A failed Save keeps the editor open. Only console.js changed for this update; Ctrl+F5 after copying it.

NBK UI filter: Packages/dropdowns show case-sensitive NBK prefixes only. Files defaults to All NBK packages and lists existing config.cnf files. View / Edit selects its owning package. Select one package to create a file or view its environment/secret files. Runtime getValue and loading are unchanged. Copy all config/pub files and Ctrl+F5; no Java compilation required for this UI update.

NBK JVM LOADER UPDATE
Existing NBK*/config/config.cnf files are loaded at startup and explicit reload without migration. Active environment overrides remain supported. Non-NBK business packages are excluded; an explicitly configured globalPackage remains supported. manager.properties is still read from config/config. Encrypted handles require the new encrypted store and master key; this does not decode the original WxConfig store. No per-lookup file access.

INSTALL THIS JAVA UPDATE
1. Back up the installed config package.
2. Copy included config/pub assets.
3. In Designer, open config.services:getValue, select Shared Source and replace the shared code using designer-source/SHARED_SOURCE.java.txt. Preserve/verify imports against IMPORTS.txt. Shared Source applies to the config.services folder; do not paste the whole class into a service body.
4. Save/compile the Java services in config.services, including startup, getValue, dispatch and resetServerCache, so every generated service uses the updated shared code. The included node.idf is the deployment metadata alternative; refresh Designer and compile after overlaying it.
5. Keep your existing config/config data directory and secrets unchanged.
6. Reload the config package so startup runs, then use Reload Configuration on each node; verify an existing NBK key through getValue with its package name. Ctrl+F5 the DSP.
7. Changes still require Save then Reload Configuration; a restart runs startup automatically.

Validation: 62 simulated IS checks passed, including NBK discovery, existing-file load, disk-free cached lookup, reload, restart, encryption, migration, concurrent snapshot readers and combined cache reset. Actual IS validation remains required.
