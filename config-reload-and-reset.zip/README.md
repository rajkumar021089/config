# Combined DSP reset action

Updates the existing working config v2 DSP button to:
**Reload Configuration + Reset Service Cache**.

Order:
1. Read, validate and publish the saved configuration on this node.
2. Invoke pub.cache.serviceResults:resetServerCache to clear IS service results.

If step 1 fails, step 2 is not invoked and the old configuration remains active.
If step 2 fails, the new configuration remains active and the DSP reports partial
success. The response includes configurationReloaded and serviceResultsReset flags.
Clearing service-result caches can cause their next invocations to execute again;
this is an explicit administrative action, not part of each configuration lookup.

## Install on the existing working package

1. Back up the installed config package outside the packages directory.
2. Copy this patch's config/pub files over the installed config/pub files.
3. Copy config/ns/config/services/dispatch/java.frag over the installed matching
   file, refresh Designer, open config.services:dispatch and Ctrl+S to compile.
   Or paste designer-source/dispatch.java.txt into that service's Source body and
   save/compile it. No Shared Source changes are needed for this patch.
4. The service must show a new `case "resetAll"` block. Keep its existing admin ACL.
5. Refresh the DSP with Ctrl+F5. If an old token is rejected after compilation,
   reload the page to get a fresh token.
6. Save a harmless demo.timeout change, use the new combined button and verify
   getValue returns the saved value. The completion message reports both results.

The included code/source/config/services.java is an updated readable source mirror;
it is optional when applying through Designer. It uses the original v2 layout, not
the separate earlier experimental cache-owner patch. Your confirmed working DSP
reload does not require that experimental patch. Do not combine source layouts.

No config/config directory is included, so saved values, environment settings and
secret stores are not overwritten. No business wrapper changes are required.
The standard IBM Administrator button and all IBM/WmRoot services remain unchanged.
Only the DSP button calls the two operations. Execute on each intended node via a
direct admin URL; it does not propagate to the four-node cluster.

## Validation

58 checks passed against simulated IS APIs, including successful combined reset,
validation failure, partial success and preservation of configuration-only reset.
JavaScript syntax and namespace XML checks passed. Actual IS built-in service ACLs,
cache behavior and browser rendering still need the development-server smoke test.

Save UI update: a successful file Save closes the editor, clears its contents, and scrolls to the success message. A failed Save keeps the editor open. Only console.js changed for this update; Ctrl+F5 after copying it.
