# Master key without wrapper changes

This version supports masterKeyFile in the package manager settings. No custom_wrapper.conf or environment variable change is required.

1. Install/compile updated package Java code and reload the config package. Preserve existing config/config files and master key.
2. Provision a Base64-encoded random 32-byte key in a protected file outside packages, readable by the IS OS user. Reuse an existing key if secrets were already stored. Do not regenerate it.
3. Add this PATH ONLY to packages/config/config/manager.properties:

masterKeyFile=/esb/config-security/config-master.key

4. Save manager.properties and retry Encrypt and save. The file path is read on demand before the first encryption; no IS restart is needed for this first-time setup. Reload Configuration after saving the secret.

The key itself must not be placed in manager.properties or Git. Keep its backup secure. All nodes sharing encrypted stores must use the same key. The loaded key is cached for the package lifetime; changing keys is a separate rotation operation, not supported by simply changing this property. Existing CONFIG_MASTER_KEY environment or config.masterKeyFile JVM settings take precedence when present.

Package-wise encrypted UI and fast in-memory listing remain included. 96 simulated checks passed, including manager-only key provisioning with no wrapper property/environment key. Actual IS verification remains required.
