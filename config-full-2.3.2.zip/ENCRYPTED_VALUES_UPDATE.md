# Encrypted Values: all packages and direct update

Build config-2.3.1-20261031. Install full source/ns/pub assets preserving your existing config/config directory and external key. Compile config.services Java services, reload package and Ctrl+F5 browser. Status must report this build.

Open Encrypted Values. The package selector is hidden. All configured matching packages are scanned on this administration page only. Each row shows package, handle, configured/missing status, file/key references, and Add value or Update value.

Click Add/Update, enter the new secret, Encrypt and save. Only config.secrets.cnf in that package is written; original property files, references and comments stay unchanged. Successful save closes the panel and reports disk save. Reload Configuration activates the values. A failed save keeps the panel available; the password field is cleared. Existing plaintext is never revealed in this page. Master-key provisioning is still required. No automatic secret migration occurs.

Malformed references are listed with their file/key and a link to the file. These no longer block other configuration activation. Attempting to retrieve a malformed encrypted value throws an error. You must correct its syntax before that individual value can be used. Missing handles similarly fail on plaintext retrieval until entered. Invalid stored ciphertext and invalid properties syntax still reject reload.

Concurrent edits to a package secret store are rejected by version checks. Refresh/reopen the row after a stale-save message. Errors from one package are displayed in its row while other package inventories continue loading. Administration scans do not run during getValue lookups.

95 simulated Java checks passed; JavaScript syntax and DSP control IDs verified. Browser/real-IS testing is still required.
