# Encrypted inventory performance update
Build config-2.3.1-20261031

The Encrypted Values tab now makes ONE secretsAll inventory request instead of a separate disk-scanning request per package. It uses the loaded JVM snapshot. Inventory JSON is built once per snapshot and reused until reload. No configuration file reads or secret decryptions occur while listing. Rows are inserted through one document fragment. Opening Add/Update reads only the selected secret store version (secretEditInfo), and saving still verifies that version. Successful saves show Saved on disk - reload pending. Reload Configuration refreshes the inventory and runtime values. Unsaved or not-yet-reloaded file changes are intentionally absent from the snapshot listing. Normal getValue behavior is unchanged.

Install the complete config/ns, config/code and config/pub updates, preserving config/config data and external master key. Compile Java services, reload package, then Ctrl+F5 the browser. Status must report config-2.3.1-20261031. A UI-only copy is insufficient because secretsAll and secretEditInfo are new backend actions.

95 simulated checks passed. Includes inventory access with package files temporarily offline, cached response reuse, on-demand edit version and refresh after reload. Real IS/browser performance still needs verification; no latency target is claimed.
